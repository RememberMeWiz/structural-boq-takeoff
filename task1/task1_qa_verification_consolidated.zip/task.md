# Project Task List — Phase: Member Size Extraction & Schedule QA

- [x] **Task 3.1: Implement Regex Parser for CAD Annotations**
  - Extract member tags (e.g., `GB-1`, `C-1`) and dimensions (e.g., `350x750`) from text entities on `Beam Label` and `Column Label` layers.
- [x] **Task 3.2: Implement Spatial Proximity Linker**
  - Write geometry proximity logic to map each text annotation coordinates `(x, y)` to its nearest physical line segment in the CAD layout.
- [x] **Task 3.3: Rebuild Member-Level Excel Schedule**
  - Export structured member-level schedules (`outputs/takeoff_member_schedule_residential.xlsx` & `outputs/takeoff_member_schedule_vcngc.xlsx`) listing each member with its mark, width, depth, and length.
- [x] **Task 3.4: Run Full QA Cross-Check**
  - Run `takeoff_comparator.py` to check for missing/extra members and size mismatches against checked ground truth schedules.



## Phase 2 BOQ System Tasks
- [x] Workspace Initialization
  - [x] Create project subfolders locally in `E:\Users\Louis\Documents\boq_system`
  - [x] Generate database schema script (`boq_schema.sql`)
  - [x] Create project descriptions, roadmaps, and instructions files
- [ ] Database Setup
  - [ ] Execute `boq_schema.sql` inside the Supabase SQL Editor
  - [ ] Validate table creations and seed data inside `fajardo_factors`
- [x] Pipeline Design
  - [x] Implement conversion script using ODA File Converter CLI for drawing inputs
  - [x] Implement initial CAD parser using `ezdxf`
  - [x] Build Fajardo Quantity Takeoff Engine (`fajardo_takeoff_engine.py`) for Concrete, Rebar, and Masonry trades
  - [x] Implement multi-sheet Excel BOQ Generator (`boq_excel_generator.py`) exporting `outputs/takeoff_boq_schedule.xlsx` with live formulas
  - [x] Add complete unit test suite (`test_fajardo_takeoff_engine.py`) and verify 100% test pass rate

## Shipping & Deployment (Deferred)

- [ ] Configure the packaged application to use the locally installed ODA File Converter for automatic DWG-to-DXF conversion.
- [ ] Add a DWG import screen/status flow, including conversion errors and recovery guidance.
- [ ] Preserve PDFs as review and validation references; schedule direct PDF extraction as a later, separate feature.

## Phase 3 Engine QA Verification

- [x] Add dual-method checks for concrete volume, PNS 49 / ASTM A615 rebar weight, and CHB count; flag divergences above 2%.
- [x] Add separate Mortar and Plaster Class A/B/C/D handling, retaining the approved Class B factors as the default.
- [x] Deduct wall openings from CHB and plaster quantities and expand the engine test suite.
- [x] **Final QA sign-off:** Retrieved the authoritative v2.0 technical specification from cloud storage and performed the final requirement-by-requirement audit. Found and fixed 4 discrepancies (Class B mortar/plaster baseline factors, Class A-D cement scaling ratio, missing plastering dual cross-check, floating-point threshold edge case). See `phase3_engine_qa_verification_report.md`. Prior `outputs/qa/project_audit_report.md` "PASSED & SIGNED-OFF" status should be treated as superseded — it only checked file existence and Excel formula integrity, not spec compliance.

## Open Items Flagged (Not Yet Scheduled)

- [ ] Masonry vertical/horizontal cell reinforcement (jamb rebar) — in-scope per tech_spec.md §1.4.2 but not implemented in the engine.
- [ ] Masonry §2.5.3 dual-check item 2 (CHB Reinforcement: Direct Counting vs. Unit-CHB Method vs. Area Method) — depends on the item above.
- [ ] Column main bar length formula (H_architectural + splice + hook + dowel, tracked independently of concrete clear height, §2.5.2).
- [ ] Rebar dual cross-check is currently close to tautological (table value vs. the formula that generated the table) — consider a genuinely independent second method.
- [ ] **Security:** rotate the Supabase `service_role` key currently exposed in `00_INSTRUCTIONS_FOR_AI.md` (a public storage file) — see QA report header.
